from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path
from datetime import datetime

app = Flask(__name__)
app.secret_key = "demo-secret-change-before-real-use"
DB_PATH = Path(__file__).with_name("hostel.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS complaints (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_name TEXT NOT NULL,
                room_number TEXT NOT NULL,
                category TEXT NOT NULL,
                description TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'Pending',
                created_at TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS resources (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_name TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                condition TEXT NOT NULL
            )
        """)
        count = conn.execute("SELECT COUNT(*) FROM resources").fetchone()[0]
        if count == 0:
            conn.executemany(
                "INSERT INTO resources (resource_name, quantity, condition) VALUES (?, ?, ?)",
                [
                    ("Ceiling fans", 12, "2 need repair"),
                    ("Study lights", 20, "Available"),
                    ("Beds", 30, "Available"),
                    ("Water purifiers", 3, "1 needs service")
                ]
            )

@app.route("/")
def index():
    with get_db() as conn:
        complaints = conn.execute("SELECT * FROM complaints ORDER BY id DESC").fetchall()
        resources = conn.execute("SELECT * FROM resources ORDER BY resource_name").fetchall()
    stats = {
        "total": len(complaints),
        "pending": sum(c["status"] == "Pending" for c in complaints),
        "progress": sum(c["status"] == "In Progress" for c in complaints),
        "resolved": sum(c["status"] == "Resolved" for c in complaints),
    }
    return render_template("index.html", complaints=complaints, resources=resources, stats=stats)

@app.route("/complaint", methods=["POST"])
def add_complaint():
    student_name = request.form.get("student_name", "").strip()
    room_number = request.form.get("room_number", "").strip()
    category = request.form.get("category", "").strip()
    description = request.form.get("description", "").strip()

    if not all([student_name, room_number, category, description]):
        flash("Please fill in every field.", "error")
        return redirect(url_for("index"))

    with get_db() as conn:
        conn.execute(
            """INSERT INTO complaints
               (student_name, room_number, category, description, status, created_at)
               VALUES (?, ?, ?, ?, 'Pending', ?)""",
            (student_name, room_number, category, description,
             datetime.now().strftime("%d %b %Y, %I:%M %p"))
        )
    flash("Complaint submitted successfully!", "success")
    return redirect(url_for("index"))

@app.route("/status/<int:complaint_id>", methods=["POST"])
def update_status(complaint_id):
    status = request.form.get("status", "")
    if status not in ["Pending", "In Progress", "Resolved"]:
        flash("Invalid status selected.", "error")
        return redirect(url_for("index"))
    with get_db() as conn:
        conn.execute("UPDATE complaints SET status = ? WHERE id = ?", (status, complaint_id))
    flash(f"Complaint #{complaint_id} status updated to {status}.", "success")
    return redirect(url_for("index"))

@app.route("/resource/<int:resource_id>", methods=["POST"])
def update_resource(resource_id):
    condition = request.form.get("condition", "").strip()
    allowed = ["Available", "Needs repair", "Needs service", "2 need repair", "1 needs service"]
    if condition not in allowed:
        flash("Please select a valid resource condition.", "error")
        return redirect(url_for("index"))
    with get_db() as conn:
        conn.execute("UPDATE resources SET condition = ? WHERE id = ?", (condition, resource_id))
    flash("Resource record updated.", "success")
    return redirect(url_for("index"))

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
