HOSTELCARE - SMART HOSTEL COMPLAINT & RESOURCE MANAGEMENT DEMO

WHAT THIS DEMO DOES
1. Students can submit a hostel complaint.
2. Complaints are saved in a local SQLite database.
3. New complaints start as Pending.
4. A warden can update a complaint to In Progress or Resolved.
5. A dashboard shows complaint counts.
6. Sample hostel resources can be viewed and their condition updated.

HOW TO RUN ON WINDOWS
1. Install Python 3 if it is not already installed. During installation, select "Add Python to PATH".
2. Extract this ZIP file to a folder, for example Documents\hostel_complaint_demo.
3. Open that folder in VS Code.
4. Open Terminal > New Terminal.
5. Run:
   python -m venv venv
6. Activate the environment:
   .\venv\Scripts\activate
7. Install Flask:
   pip install -r requirements.txt
8. Start the app:
   python app.py
9. Open the local URL printed in the terminal, usually:
   http://127.0.0.1:5000

DEMO PLAN
- Submit a complaint: "Water leakage near bathroom" in room B-204.
- Show that it appears in Complaint Tracker as Pending.
- Change it to In Progress and click Save.
- Change it to Resolved and click Save.
- Show that the dashboard totals change.
- Scroll to Resource Overview and update a resource condition.

DATABASE
The app automatically creates hostel.db in the same folder when it starts.
Tables: complaints, resources.

IMPORTANT
This is a classroom prototype. It does not yet include real login, cloud deployment, NoSQL, graph database, or a cache. Do not use real student personal data or present this demo as production-secure. Add authentication and authorization before any real deployment.
